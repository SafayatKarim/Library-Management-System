﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BL;
using BEL;
using System.Data.SqlClient;

namespace Library
{
    public partial class admin : Form
    {
       
        
        public Operations opr = new Operations();
        private string id;
        DataTable dt = new DataTable();


        public admin()
        {
            InitializeComponent();
        }



            public admin(string id)
            {
                InitializeComponent();
                this.id = id;
            dt = opr.adminprofilefunc(id);
            dgtv.DataSource = dt;
            dgtv.Columns[0].Visible = false;
            dgtv.Columns[7].Visible = false;
            dgtv.Columns[8].Visible = false;

            }

            private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            DisplayInfo dis = new DisplayInfo(this);
           
            
            dis.Show();
        }

        private void librarianToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
          
            RgLibadmin rg = new RgLibadmin(this);
           
            rg.Show();
            

        }

        private void booksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
           displaybook dis = new displaybook(this);
            
            dis.Show();
            

        }
        

        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            BkRegAdmin b = new BkRegAdmin(this);
            b.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure To Logout  ??", "Enquery", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Hide();
                Login ln = new Login();
                ln.Show();
               
            }
            else if(result == DialogResult.No){ this.Show(); }
        }

        private void studentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            regstdadmin st = new regstdadmin(this);
            st.Show();
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
           DialogResult result = MessageBox.Show("DO You want Exit ??", "Enquery", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {

                Application.Exit();
            }
            else if (result==DialogResult.No) {
                this.Show();

            }
            
        }

        private void studentToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            DisStdFrmAdmin dt = new DisStdFrmAdmin(this);
            dt.Show();
        }

        private void dgtv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void admin_Load(object sender, EventArgs e)
        {

        }

        private void issueDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            issueshowadmin ie = new issueshowadmin(this);
            ie.Show();
        }

        private void studentToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Hide();
            promotion pr = new promotion(this);
            pr.Show();
        }

        private void promotionToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}

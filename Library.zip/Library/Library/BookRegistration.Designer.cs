﻿namespace Library
{
    partial class BkRegLibEmp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblbn = new System.Windows.Forms.Label();
            this.tbbn = new System.Windows.Forms.TextBox();
            this.tbbt = new System.Windows.Forms.TextBox();
            this.lblt = new System.Windows.Forms.Label();
            this.tba = new System.Windows.Forms.TextBox();
            this.lnla = new System.Windows.Forms.Label();
            this.tbq = new System.Windows.Forms.TextBox();
            this.lblq = new System.Windows.Forms.Label();
            this.tbe = new System.Windows.Forms.TextBox();
            this.lble = new System.Windows.Forms.Label();
            this.bab = new System.Windows.Forms.Button();
            this.lbld = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblbn
            // 
            this.lblbn.AutoSize = true;
            this.lblbn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbn.Location = new System.Drawing.Point(47, 49);
            this.lblbn.Name = "lblbn";
            this.lblbn.Size = new System.Drawing.Size(101, 20);
            this.lblbn.TabIndex = 0;
            this.lblbn.Text = "Book Name";
            // 
            // tbbn
            // 
            this.tbbn.Location = new System.Drawing.Point(211, 49);
            this.tbbn.Name = "tbbn";
            this.tbbn.Size = new System.Drawing.Size(291, 26);
            this.tbbn.TabIndex = 1;
            // 
            // tbbt
            // 
            this.tbbt.Location = new System.Drawing.Point(211, 112);
            this.tbbt.Name = "tbbt";
            this.tbbt.Size = new System.Drawing.Size(291, 26);
            this.tbbt.TabIndex = 3;
            // 
            // lblt
            // 
            this.lblt.AutoSize = true;
            this.lblt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblt.Location = new System.Drawing.Point(59, 118);
            this.lblt.Name = "lblt";
            this.lblt.Size = new System.Drawing.Size(89, 20);
            this.lblt.TabIndex = 2;
            this.lblt.Text = "Book Title";
            // 
            // tba
            // 
            this.tba.Location = new System.Drawing.Point(211, 241);
            this.tba.Name = "tba";
            this.tba.Size = new System.Drawing.Size(291, 26);
            this.tba.TabIndex = 5;
            // 
            // lnla
            // 
            this.lnla.AutoSize = true;
            this.lnla.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnla.Location = new System.Drawing.Point(85, 247);
            this.lnla.Name = "lnla";
            this.lnla.Size = new System.Drawing.Size(63, 20);
            this.lnla.TabIndex = 4;
            this.lnla.Text = "Author";
            // 
            // tbq
            // 
            this.tbq.Location = new System.Drawing.Point(211, 362);
            this.tbq.Name = "tbq";
            this.tbq.Size = new System.Drawing.Size(291, 26);
            this.tbq.TabIndex = 9;
            // 
            // lblq
            // 
            this.lblq.AutoSize = true;
            this.lblq.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblq.Location = new System.Drawing.Point(72, 368);
            this.lblq.Name = "lblq";
            this.lblq.Size = new System.Drawing.Size(76, 20);
            this.lblq.TabIndex = 8;
            this.lblq.Text = "Quantity";
            // 
            // tbe
            // 
            this.tbe.Location = new System.Drawing.Point(211, 303);
            this.tbe.Name = "tbe";
            this.tbe.Size = new System.Drawing.Size(291, 26);
            this.tbe.TabIndex = 7;
            // 
            // lble
            // 
            this.lble.AutoSize = true;
            this.lble.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lble.Location = new System.Drawing.Point(83, 309);
            this.lble.Name = "lble";
            this.lble.Size = new System.Drawing.Size(65, 20);
            this.lble.TabIndex = 6;
            this.lble.Text = "Edition";
            // 
            // bab
            // 
            this.bab.BackColor = System.Drawing.Color.Lime;
            this.bab.Location = new System.Drawing.Point(340, 483);
            this.bab.Name = "bab";
            this.bab.Size = new System.Drawing.Size(162, 59);
            this.bab.TabIndex = 10;
            this.bab.Text = "Add Book";
            this.bab.UseVisualStyleBackColor = false;
            this.bab.Click += new System.EventHandler(this.bab_Click);
            // 
            // lbld
            // 
            this.lbld.AutoSize = true;
            this.lbld.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbld.Location = new System.Drawing.Point(44, 174);
            this.lbld.Name = "lbld";
            this.lbld.Size = new System.Drawing.Size(104, 20);
            this.lbld.TabIndex = 11;
            this.lbld.Text = "Department";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(63, 483);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(162, 59);
            this.button1.TabIndex = 13;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "CS",
            "EEE",
            "BBA",
            "LAW",
            "Arch",
            "Math",
            "Science"});
            this.comboBox1.Location = new System.Drawing.Point(211, 171);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(291, 28);
            this.comboBox1.TabIndex = 14;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // BkRegLibEmp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(596, 651);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbld);
            this.Controls.Add(this.bab);
            this.Controls.Add(this.tbq);
            this.Controls.Add(this.lblq);
            this.Controls.Add(this.tbe);
            this.Controls.Add(this.lble);
            this.Controls.Add(this.tba);
            this.Controls.Add(this.lnla);
            this.Controls.Add(this.tbbt);
            this.Controls.Add(this.lblt);
            this.Controls.Add(this.tbbn);
            this.Controls.Add(this.lblbn);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BkRegLibEmp";
            this.Text = "Book  Registration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblbn;
        private System.Windows.Forms.TextBox tbbn;
        private System.Windows.Forms.TextBox tbbt;
        private System.Windows.Forms.Label lblt;
        private System.Windows.Forms.TextBox tba;
        private System.Windows.Forms.Label lnla;
        private System.Windows.Forms.TextBox tbq;
        private System.Windows.Forms.Label lblq;
        private System.Windows.Forms.TextBox tbe;
        private System.Windows.Forms.Label lble;
        private System.Windows.Forms.Button bab;
        private System.Windows.Forms.Label lbld;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}
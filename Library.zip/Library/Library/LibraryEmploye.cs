﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BL;
using BEL;

namespace Library
{
    public partial class LibraryEmploye : Form
    {
        public Operations opr = new Operations();
        private string id;
        DataTable dt = new DataTable();
        

        public LibraryEmploye()
        {
            InitializeComponent();
        }

        public LibraryEmploye(string id)
        {
            InitializeComponent();

            this.id = id;
            dt = opr.adminprofilefunc(id);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[7].Visible = false;
            dataGridView1.Columns[8].Visible = false;
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure To Logout  ??", "Enquery", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Hide();
                Login ln = new Login();
                ln.Show();

            }
            else if (result == DialogResult.No) { this.Show(); }

        }

        private void studentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            regstLibEmp rs = new regstLibEmp();
            
            rs.Show();
            
        }

        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();

            BkRegLibEmp b = new BkRegLibEmp();
            b.Show();
        }

        private void bookToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            disbooklib db = new disbooklib(this);
            db.Show();
        }
       

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("DO You want Exit ??", "Enquery", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {

                Application.Exit();
            }
            else if (result == DialogResult.No)
            {
                this.Show();

            }
        }

        private void studentToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            disstdfrmLib dt = new disstdfrmLib (this);
            dt.Show();
        }

        private void issueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            issue b = new issue(this);
            b.Show();
        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            issueshowlibemp s = new issueshowlibemp(this);
            s.Show();

        }

        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            returnbook rb = new returnbook(this);
            rb.Show();
        }
    }
}

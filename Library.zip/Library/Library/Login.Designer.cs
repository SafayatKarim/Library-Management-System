﻿namespace Library
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblunl = new System.Windows.Forms.Label();
            this.tbuname = new System.Windows.Forms.TextBox();
            this.tbpass = new System.Windows.Forms.TextBox();
            this.lblpl = new System.Windows.Forms.Label();
            this.blgnl = new System.Windows.Forms.Button();
            this.btnRegistration = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblunl
            // 
            this.lblunl.AutoSize = true;
            this.lblunl.ForeColor = System.Drawing.Color.White;
            this.lblunl.Location = new System.Drawing.Point(48, 119);
            this.lblunl.Name = "lblunl";
            this.lblunl.Size = new System.Drawing.Size(98, 20);
            this.lblunl.TabIndex = 0;
            this.lblunl.Text = "User Name";
            // 
            // tbuname
            // 
            this.tbuname.Location = new System.Drawing.Point(173, 119);
            this.tbuname.Name = "tbuname";
            this.tbuname.Size = new System.Drawing.Size(147, 26);
            this.tbuname.TabIndex = 0;
            // 
            // tbpass
            // 
            this.tbpass.Location = new System.Drawing.Point(173, 191);
            this.tbpass.Name = "tbpass";
            this.tbpass.PasswordChar = '*';
            this.tbpass.Size = new System.Drawing.Size(147, 26);
            this.tbpass.TabIndex = 1;
            // 
            // lblpl
            // 
            this.lblpl.AutoSize = true;
            this.lblpl.ForeColor = System.Drawing.Color.White;
            this.lblpl.Location = new System.Drawing.Point(48, 197);
            this.lblpl.Name = "lblpl";
            this.lblpl.Size = new System.Drawing.Size(86, 20);
            this.lblpl.TabIndex = 2;
            this.lblpl.Text = "Password";
            // 
            // blgnl
            // 
            this.blgnl.BackColor = System.Drawing.Color.Lime;
            this.blgnl.Location = new System.Drawing.Point(201, 266);
            this.blgnl.Name = "blgnl";
            this.blgnl.Size = new System.Drawing.Size(94, 40);
            this.blgnl.TabIndex = 2;
            this.blgnl.Text = "Login";
            this.blgnl.UseVisualStyleBackColor = false;
            this.blgnl.Click += new System.EventHandler(this.blgnl_Click);
            // 
            // btnRegistration
            // 
            this.btnRegistration.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnRegistration.Location = new System.Drawing.Point(271, 436);
            this.btnRegistration.Name = "btnRegistration";
            this.btnRegistration.Size = new System.Drawing.Size(128, 42);
            this.btnRegistration.TabIndex = 5;
            this.btnRegistration.Text = "Registration";
            this.btnRegistration.UseVisualStyleBackColor = false;
            this.btnRegistration.Click += new System.EventHandler(this.btnRegistration_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(40, 342);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 40);
            this.button1.TabIndex = 3;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label1.Location = new System.Drawing.Point(58, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(328, 37);
            this.label1.TabIndex = 8;
            this.label1.Text = "Library Management";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(197, 399);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Haven\'t an account ??";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(21, 413);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Forget Password?";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button2.Location = new System.Drawing.Point(58, 436);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 42);
            this.button2.TabIndex = 4;
            this.button2.Text = "Click";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(400, 500);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnRegistration);
            this.Controls.Add(this.blgnl);
            this.Controls.Add(this.tbpass);
            this.Controls.Add(this.lblpl);
            this.Controls.Add(this.tbuname);
            this.Controls.Add(this.lblunl);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(500, 10);
            this.Name = "Login";
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblunl;
        private System.Windows.Forms.TextBox tbuname;
        private System.Windows.Forms.TextBox tbpass;
        private System.Windows.Forms.Label lblpl;
        private System.Windows.Forms.Button blgnl;
        private System.Windows.Forms.Button btnRegistration;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
    }
}
﻿namespace Library
{
    partial class displaybook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bookadmin = new System.Windows.Forms.DataGridView();
            this.btnBack = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnsearch = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblbn = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnfilter = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.tbname = new System.Windows.Forms.TextBox();
            this.tbedition = new System.Windows.Forms.TextBox();
            this.tbauthor = new System.Windows.Forms.TextBox();
            this.tbqun = new System.Windows.Forms.TextBox();
            this.tbdept = new System.Windows.Forms.TextBox();
            this.tbtile = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lbledition = new System.Windows.Forms.Label();
            this.lblauthor = new System.Windows.Forms.Label();
            this.lblqun = new System.Windows.Forms.Label();
            this.lbldept = new System.Windows.Forms.Label();
            this.lbltitle = new System.Windows.Forms.Label();
            this.tbid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bookadmin)).BeginInit();
            this.SuspendLayout();
            // 
            // bookadmin
            // 
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bookadmin.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.bookadmin.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bookadmin.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bookadmin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bookadmin.Location = new System.Drawing.Point(532, 12);
            this.bookadmin.Name = "bookadmin";
            this.bookadmin.RowTemplate.Height = 28;
            this.bookadmin.Size = new System.Drawing.Size(791, 623);
            this.bookadmin.TabIndex = 0;
            this.bookadmin.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bookadmin_CellContentClick);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.Blue;
            this.btnBack.Location = new System.Drawing.Point(21, 22);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(79, 39);
            this.btnBack.TabIndex = 1;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Fuchsia;
            this.button1.Location = new System.Drawing.Point(267, 22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(79, 39);
            this.button1.TabIndex = 2;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnsearch.Location = new System.Drawing.Point(12, 347);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(113, 39);
            this.btnsearch.TabIndex = 3;
            this.btnsearch.Text = "Search";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 406);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(122, 26);
            this.textBox1.TabIndex = 4;
            // 
            // lblbn
            // 
            this.lblbn.AutoSize = true;
            this.lblbn.BackColor = System.Drawing.Color.White;
            this.lblbn.Location = new System.Drawing.Point(17, 465);
            this.lblbn.Name = "lblbn";
            this.lblbn.Size = new System.Drawing.Size(114, 20);
            this.lblbn.TabIndex = 5;
            this.lblbn.Text = "By Book Name";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(12, 161);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(129, 26);
            this.textBox2.TabIndex = 7;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "CS",
            "EEE",
            "BBA",
            "LAW",
            "Arch",
            "Math",
            "Science"});
            this.comboBox1.Location = new System.Drawing.Point(12, 292);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(129, 28);
            this.comboBox1.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(20, 195);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "By Book Name";
            // 
            // btnfilter
            // 
            this.btnfilter.BackColor = System.Drawing.Color.Aqua;
            this.btnfilter.Location = new System.Drawing.Point(21, 231);
            this.btnfilter.Name = "btnfilter";
            this.btnfilter.Size = new System.Drawing.Size(113, 39);
            this.btnfilter.TabIndex = 11;
            this.btnfilter.Text = "Filter book";
            this.btnfilter.UseVisualStyleBackColor = false;
            this.btnfilter.Click += new System.EventHandler(this.btnfilter_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.CadetBlue;
            this.btndelete.Location = new System.Drawing.Point(21, 106);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(113, 39);
            this.btndelete.TabIndex = 12;
            this.btndelete.Text = "Delete Book";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.SteelBlue;
            this.button2.Location = new System.Drawing.Point(2, 524);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(132, 45);
            this.button2.TabIndex = 13;
            this.button2.Text = "View Books";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.Lime;
            this.btnupdate.Location = new System.Drawing.Point(298, 562);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(150, 51);
            this.btnupdate.TabIndex = 14;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.button3_Click);
            // 
            // tbname
            // 
            this.tbname.Location = new System.Drawing.Point(338, 169);
            this.tbname.Name = "tbname";
            this.tbname.Size = new System.Drawing.Size(100, 26);
            this.tbname.TabIndex = 15;
            // 
            // tbedition
            // 
            this.tbedition.Location = new System.Drawing.Point(338, 230);
            this.tbedition.Name = "tbedition";
            this.tbedition.Size = new System.Drawing.Size(100, 26);
            this.tbedition.TabIndex = 16;
            // 
            // tbauthor
            // 
            this.tbauthor.Location = new System.Drawing.Point(338, 304);
            this.tbauthor.Name = "tbauthor";
            this.tbauthor.Size = new System.Drawing.Size(100, 26);
            this.tbauthor.TabIndex = 17;
            // 
            // tbqun
            // 
            this.tbqun.Location = new System.Drawing.Point(338, 500);
            this.tbqun.Name = "tbqun";
            this.tbqun.Size = new System.Drawing.Size(100, 26);
            this.tbqun.TabIndex = 20;
            // 
            // tbdept
            // 
            this.tbdept.Location = new System.Drawing.Point(338, 430);
            this.tbdept.Name = "tbdept";
            this.tbdept.Size = new System.Drawing.Size(100, 26);
            this.tbdept.TabIndex = 19;
            // 
            // tbtile
            // 
            this.tbtile.Location = new System.Drawing.Point(338, 366);
            this.tbtile.Name = "tbtile";
            this.tbtile.Size = new System.Drawing.Size(100, 26);
            this.tbtile.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(192, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Book ID";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(208, 175);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(51, 20);
            this.lblname.TabIndex = 22;
            this.lblname.Text = "Name";
            // 
            // lbledition
            // 
            this.lbledition.AutoSize = true;
            this.lbledition.Location = new System.Drawing.Point(208, 233);
            this.lbledition.Name = "lbledition";
            this.lbledition.Size = new System.Drawing.Size(58, 20);
            this.lbledition.TabIndex = 23;
            this.lbledition.Text = "Edition";
            // 
            // lblauthor
            // 
            this.lblauthor.AutoSize = true;
            this.lblauthor.Location = new System.Drawing.Point(208, 310);
            this.lblauthor.Name = "lblauthor";
            this.lblauthor.Size = new System.Drawing.Size(57, 20);
            this.lblauthor.TabIndex = 24;
            this.lblauthor.Text = "Author";
            // 
            // lblqun
            // 
            this.lblqun.AutoSize = true;
            this.lblqun.Location = new System.Drawing.Point(208, 500);
            this.lblqun.Name = "lblqun";
            this.lblqun.Size = new System.Drawing.Size(68, 20);
            this.lblqun.TabIndex = 27;
            this.lblqun.Text = "Quantity";
            // 
            // lbldept
            // 
            this.lbldept.AutoSize = true;
            this.lbldept.Location = new System.Drawing.Point(168, 430);
            this.lbldept.Name = "lbldept";
            this.lbldept.Size = new System.Drawing.Size(91, 20);
            this.lbldept.TabIndex = 26;
            this.lbldept.Text = "department";
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Location = new System.Drawing.Point(208, 372);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(38, 20);
            this.lbltitle.TabIndex = 25;
            this.lbltitle.Text = "Title";
            // 
            // tbid
            // 
            this.tbid.Location = new System.Drawing.Point(338, 119);
            this.tbid.Name = "tbid";
            this.tbid.ReadOnly = true;
            this.tbid.Size = new System.Drawing.Size(100, 26);
            this.tbid.TabIndex = 28;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label2.Location = new System.Drawing.Point(459, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 20);
            this.label2.TabIndex = 29;
            this.label2.Text = "Fixed";
            // 
            // displaybook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(1352, 659);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbid);
            this.Controls.Add(this.lblqun);
            this.Controls.Add(this.lbldept);
            this.Controls.Add(this.lbltitle);
            this.Controls.Add(this.lblauthor);
            this.Controls.Add(this.lbledition);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbqun);
            this.Controls.Add(this.tbdept);
            this.Controls.Add(this.tbtile);
            this.Controls.Add(this.tbauthor);
            this.Controls.Add(this.tbedition);
            this.Controls.Add(this.tbname);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnfilter);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lblbn);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.bookadmin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "displaybook";
            this.Text = "displaybook";
            this.Load += new System.EventHandler(this.displaybook_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bookadmin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView bookadmin;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblbn;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnfilter;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.TextBox tbname;
        private System.Windows.Forms.TextBox tbedition;
        private System.Windows.Forms.TextBox tbauthor;
        private System.Windows.Forms.TextBox tbqun;
        private System.Windows.Forms.TextBox tbdept;
        private System.Windows.Forms.TextBox tbtile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lbledition;
        private System.Windows.Forms.Label lblauthor;
        private System.Windows.Forms.Label lblqun;
        private System.Windows.Forms.Label lbldept;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.TextBox tbid;
        private System.Windows.Forms.Label label2;
    }
}
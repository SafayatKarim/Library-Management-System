﻿namespace Library
{
    partial class issue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbuname = new System.Windows.Forms.TextBox();
            this.tbbookname = new System.Windows.Forms.TextBox();
            this.tbstdaddress = new System.Windows.Forms.TextBox();
            this.tbstdusername = new System.Windows.Forms.TextBox();
            this.tbstdgmail = new System.Windows.Forms.TextBox();
            this.tbstdname = new System.Windows.Forms.TextBox();
            this.tbgmail = new System.Windows.Forms.TextBox();
            this.tbissuedate = new System.Windows.Forms.DateTimePicker();
            this.button5 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tbsid = new System.Windows.Forms.TextBox();
            this.tbgender = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.tbsbissue = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tbbid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.tbbqun = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // tbuname
            // 
            this.tbuname.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbuname.Location = new System.Drawing.Point(314, 10);
            this.tbuname.Name = "tbuname";
            this.tbuname.Size = new System.Drawing.Size(204, 26);
            this.tbuname.TabIndex = 1;
            // 
            // tbbookname
            // 
            this.tbbookname.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbbookname.Location = new System.Drawing.Point(183, 531);
            this.tbbookname.Name = "tbbookname";
            this.tbbookname.ReadOnly = true;
            this.tbbookname.Size = new System.Drawing.Size(204, 26);
            this.tbbookname.TabIndex = 2;
            // 
            // tbstdaddress
            // 
            this.tbstdaddress.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbstdaddress.Location = new System.Drawing.Point(183, 345);
            this.tbstdaddress.Multiline = true;
            this.tbstdaddress.Name = "tbstdaddress";
            this.tbstdaddress.ReadOnly = true;
            this.tbstdaddress.Size = new System.Drawing.Size(204, 65);
            this.tbstdaddress.TabIndex = 4;
            // 
            // tbstdusername
            // 
            this.tbstdusername.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbstdusername.Location = new System.Drawing.Point(183, 279);
            this.tbstdusername.Name = "tbstdusername";
            this.tbstdusername.ReadOnly = true;
            this.tbstdusername.Size = new System.Drawing.Size(204, 26);
            this.tbstdusername.TabIndex = 5;
            // 
            // tbstdgmail
            // 
            this.tbstdgmail.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbstdgmail.Location = new System.Drawing.Point(183, 191);
            this.tbstdgmail.Name = "tbstdgmail";
            this.tbstdgmail.ReadOnly = true;
            this.tbstdgmail.Size = new System.Drawing.Size(204, 26);
            this.tbstdgmail.TabIndex = 6;
            // 
            // tbstdname
            // 
            this.tbstdname.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbstdname.Location = new System.Drawing.Point(183, 100);
            this.tbstdname.Name = "tbstdname";
            this.tbstdname.ReadOnly = true;
            this.tbstdname.Size = new System.Drawing.Size(204, 26);
            this.tbstdname.TabIndex = 7;
            // 
            // tbgmail
            // 
            this.tbgmail.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbgmail.Location = new System.Drawing.Point(679, 10);
            this.tbgmail.Name = "tbgmail";
            this.tbgmail.Size = new System.Drawing.Size(204, 26);
            this.tbgmail.TabIndex = 9;
            // 
            // tbissuedate
            // 
            this.tbissuedate.Location = new System.Drawing.Point(130, 432);
            this.tbissuedate.Name = "tbissuedate";
            this.tbissuedate.Size = new System.Drawing.Size(284, 26);
            this.tbissuedate.TabIndex = 16;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(21, 0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(130, 47);
            this.button5.TabIndex = 17;
            this.button5.Text = "Search";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(453, 43);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(622, 184);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // tbsid
            // 
            this.tbsid.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbsid.Location = new System.Drawing.Point(183, 68);
            this.tbsid.Name = "tbsid";
            this.tbsid.ReadOnly = true;
            this.tbsid.Size = new System.Drawing.Size(204, 26);
            this.tbsid.TabIndex = 19;
            // 
            // tbgender
            // 
            this.tbgender.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbgender.Location = new System.Drawing.Point(183, 147);
            this.tbgender.Name = "tbgender";
            this.tbgender.ReadOnly = true;
            this.tbgender.Size = new System.Drawing.Size(204, 26);
            this.tbgender.TabIndex = 21;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(471, 247);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(130, 47);
            this.button10.TabIndex = 23;
            this.button10.Text = "Search Book";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // tbsbissue
            // 
            this.tbsbissue.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbsbissue.Location = new System.Drawing.Point(635, 257);
            this.tbsbissue.Name = "tbsbissue";
            this.tbsbissue.Size = new System.Drawing.Size(205, 26);
            this.tbsbissue.TabIndex = 24;
            this.tbsbissue.TextChanged += new System.EventHandler(this.tbsb_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(864, 260);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 20);
            this.label1.TabIndex = 25;
            this.label1.Text = "Book Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(453, 319);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowTemplate.Height = 28;
            this.dataGridView2.Size = new System.Drawing.Size(620, 209);
            this.dataGridView2.TabIndex = 26;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // tbbid
            // 
            this.tbbid.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbbid.Location = new System.Drawing.Point(183, 484);
            this.tbbid.Name = "tbbid";
            this.tbbid.ReadOnly = true;
            this.tbbid.Size = new System.Drawing.Size(204, 26);
            this.tbbid.TabIndex = 27;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label2.Location = new System.Drawing.Point(67, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 20);
            this.label2.TabIndex = 29;
            this.label2.Text = "Student Id";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label3.Location = new System.Drawing.Point(46, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 20);
            this.label3.TabIndex = 30;
            this.label3.Text = "Student Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label4.Location = new System.Drawing.Point(88, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 20);
            this.label4.TabIndex = 31;
            this.label4.Text = "Gender";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label5.Location = new System.Drawing.Point(101, 197);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 20);
            this.label5.TabIndex = 32;
            this.label5.Text = "Gmail";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label6.Location = new System.Drawing.Point(69, 279);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 20);
            this.label6.TabIndex = 33;
            this.label6.Text = "User Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label7.Location = new System.Drawing.Point(29, 348);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 20);
            this.label7.TabIndex = 34;
            this.label7.Text = "Student Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label8.Location = new System.Drawing.Point(29, 432);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 20);
            this.label8.TabIndex = 35;
            this.label8.Text = "Issue Date";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label9.Location = new System.Drawing.Point(67, 487);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 20);
            this.label9.TabIndex = 36;
            this.label9.Text = "Book ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label10.Location = new System.Drawing.Point(59, 537);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 20);
            this.label10.TabIndex = 37;
            this.label10.Text = "Book Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label11.Location = new System.Drawing.Point(201, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(89, 20);
            this.label11.TabIndex = 38;
            this.label11.Text = "User Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label12.Location = new System.Drawing.Point(583, 13);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 20);
            this.label12.TabIndex = 39;
            this.label12.Text = "Gmail";
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(909, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(62, 34);
            this.button1.TabIndex = 40;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(518, 548);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 47);
            this.button2.TabIndex = 41;
            this.button2.Text = "Issue Book";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label13.Location = new System.Drawing.Point(69, 585);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 20);
            this.label13.TabIndex = 45;
            this.label13.Text = "Quantity";
            // 
            // tbbqun
            // 
            this.tbbqun.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbbqun.Location = new System.Drawing.Point(183, 582);
            this.tbbqun.Name = "tbbqun";
            this.tbbqun.ReadOnly = true;
            this.tbbqun.Size = new System.Drawing.Size(204, 26);
            this.tbbqun.TabIndex = 44;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Lime;
            this.button3.Location = new System.Drawing.Point(909, 568);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(105, 37);
            this.button3.TabIndex = 46;
            this.button3.Text = "Back";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(679, 548);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(130, 47);
            this.button4.TabIndex = 47;
            this.button4.Text = "Show  Book";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // issue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1085, 647);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.tbbqun);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbbid);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbsbissue);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.tbgender);
            this.Controls.Add(this.tbsid);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.tbissuedate);
            this.Controls.Add(this.tbgmail);
            this.Controls.Add(this.tbstdname);
            this.Controls.Add(this.tbstdgmail);
            this.Controls.Add(this.tbstdusername);
            this.Controls.Add(this.tbstdaddress);
            this.Controls.Add(this.tbbookname);
            this.Controls.Add(this.tbuname);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "issue";
            this.Text = "Issue Details";
            this.Load += new System.EventHandler(this.issue_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tbuname;
        private System.Windows.Forms.TextBox tbbookname;
        private System.Windows.Forms.TextBox tbstdaddress;
        private System.Windows.Forms.TextBox tbstdusername;
        private System.Windows.Forms.TextBox tbstdgmail;
        private System.Windows.Forms.TextBox tbstdname;
        private System.Windows.Forms.TextBox tbgmail;
        private System.Windows.Forms.DateTimePicker tbissuedate;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox tbsid;
        private System.Windows.Forms.TextBox tbgender;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox tbsbissue;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox tbbid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbbqun;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
}
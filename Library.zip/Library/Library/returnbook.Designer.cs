﻿namespace Library
{
    partial class returnbook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.tbbnrb = new System.Windows.Forms.Label();
            this.tbunamerb = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbbookid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbbbbb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbbnissue = new System.Windows.Forms.TextBox();
            this.dcjnkjcnjc = new System.Windows.Forms.Label();
            this.tbsidrb = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.stdnamerb = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbqunrb = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.tttttttttt = new System.Windows.Forms.TextBox();
            this.View = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dtgvissue = new System.Windows.Forms.DataGridView();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvissue)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Location = new System.Drawing.Point(82, 15);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 38);
            this.button1.TabIndex = 2;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(348, 21);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(198, 32);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(758, 15);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(198, 38);
            this.textBox2.TabIndex = 4;
            // 
            // tbbnrb
            // 
            this.tbbnrb.AutoSize = true;
            this.tbbnrb.Location = new System.Drawing.Point(224, 24);
            this.tbbnrb.Name = "tbbnrb";
            this.tbbnrb.Size = new System.Drawing.Size(92, 20);
            this.tbbnrb.TabIndex = 5;
            this.tbbnrb.Text = "Book Name";
            // 
            // tbunamerb
            // 
            this.tbunamerb.AutoSize = true;
            this.tbunamerb.Location = new System.Drawing.Point(606, 24);
            this.tbunamerb.Name = "tbunamerb";
            this.tbunamerb.Size = new System.Drawing.Size(89, 20);
            this.tbunamerb.TabIndex = 6;
            this.tbunamerb.Text = "User Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 173);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Book ID";
            // 
            // tbbookid
            // 
            this.tbbookid.Location = new System.Drawing.Point(128, 170);
            this.tbbookid.Multiline = true;
            this.tbbookid.Name = "tbbookid";
            this.tbbookid.ReadOnly = true;
            this.tbbookid.Size = new System.Drawing.Size(188, 32);
            this.tbbookid.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Issue ID";
            // 
            // tbbbbb
            // 
            this.tbbbbb.Location = new System.Drawing.Point(128, 117);
            this.tbbbbb.Multiline = true;
            this.tbbbbb.Name = "tbbbbb";
            this.tbbbbb.ReadOnly = true;
            this.tbbbbb.Size = new System.Drawing.Size(188, 32);
            this.tbbbbb.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 221);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 20);
            this.label3.TabIndex = 14;
            this.label3.Text = "Book Name";
            // 
            // tbbnissue
            // 
            this.tbbnissue.Location = new System.Drawing.Point(128, 221);
            this.tbbnissue.Multiline = true;
            this.tbbnissue.Name = "tbbnissue";
            this.tbbnissue.ReadOnly = true;
            this.tbbnissue.Size = new System.Drawing.Size(188, 32);
            this.tbbnissue.TabIndex = 13;
            // 
            // dcjnkjcnjc
            // 
            this.dcjnkjcnjc.AutoSize = true;
            this.dcjnkjcnjc.Location = new System.Drawing.Point(18, 277);
            this.dcjnkjcnjc.Name = "dcjnkjcnjc";
            this.dcjnkjcnjc.Size = new System.Drawing.Size(87, 20);
            this.dcjnkjcnjc.TabIndex = 12;
            this.dcjnkjcnjc.Text = "Student ID";
            // 
            // tbsidrb
            // 
            this.tbsidrb.Location = new System.Drawing.Point(128, 274);
            this.tbsidrb.Multiline = true;
            this.tbsidrb.Name = "tbsidrb";
            this.tbsidrb.ReadOnly = true;
            this.tbsidrb.Size = new System.Drawing.Size(188, 32);
            this.tbsidrb.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 500);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 20);
            this.label5.TabIndex = 22;
            this.label5.Text = "Return Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 387);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 20);
            this.label6.TabIndex = 20;
            this.label6.Text = "Quantity";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 334);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 20);
            this.label7.TabIndex = 18;
            this.label7.Text = "Student Name";
            // 
            // stdnamerb
            // 
            this.stdnamerb.Location = new System.Drawing.Point(128, 331);
            this.stdnamerb.Multiline = true;
            this.stdnamerb.Name = "stdnamerb";
            this.stdnamerb.ReadOnly = true;
            this.stdnamerb.Size = new System.Drawing.Size(188, 32);
            this.stdnamerb.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 438);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 20);
            this.label8.TabIndex = 16;
            this.label8.Text = "Issue Date";
            // 
            // tbqunrb
            // 
            this.tbqunrb.Location = new System.Drawing.Point(128, 384);
            this.tbqunrb.Multiline = true;
            this.tbqunrb.Name = "tbqunrb";
            this.tbqunrb.ReadOnly = true;
            this.tbqunrb.Size = new System.Drawing.Size(188, 32);
            this.tbqunrb.TabIndex = 15;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(128, 494);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(271, 26);
            this.dateTimePicker1.TabIndex = 23;
            // 
            // tttttttttt
            // 
            this.tttttttttt.Location = new System.Drawing.Point(128, 435);
            this.tttttttttt.Multiline = true;
            this.tttttttttt.Name = "tttttttttt";
            this.tttttttttt.ReadOnly = true;
            this.tttttttttt.Size = new System.Drawing.Size(188, 32);
            this.tttttttttt.TabIndex = 24;
            // 
            // View
            // 
            this.View.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.View.Location = new System.Drawing.Point(38, 568);
            this.View.Name = "View";
            this.View.Size = new System.Drawing.Size(110, 38);
            this.View.TabIndex = 25;
            this.View.Text = "View Issues";
            this.View.UseVisualStyleBackColor = false;
            this.View.Click += new System.EventHandler(this.View_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(194, 568);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(95, 49);
            this.button2.TabIndex = 26;
            this.button2.Text = "Return";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dtgvissue
            // 
            this.dtgvissue.AllowUserToAddRows = false;
            this.dtgvissue.AllowUserToDeleteRows = false;
            this.dtgvissue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvissue.Location = new System.Drawing.Point(419, 59);
            this.dtgvissue.Name = "dtgvissue";
            this.dtgvissue.ReadOnly = true;
            this.dtgvissue.RowTemplate.Height = 28;
            this.dtgvissue.Size = new System.Drawing.Size(687, 577);
            this.dtgvissue.TabIndex = 27;
            this.dtgvissue.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvissue_CellContentClick);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(22, 59);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(95, 49);
            this.button3.TabIndex = 28;
            this.button3.Text = "Back";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // returnbook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1118, 670);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.dtgvissue);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.View);
            this.Controls.Add(this.tttttttttt);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.stdnamerb);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tbqunrb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbbnissue);
            this.Controls.Add(this.dcjnkjcnjc);
            this.Controls.Add(this.tbsidrb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbbbbb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbbookid);
            this.Controls.Add(this.tbunamerb);
            this.Controls.Add(this.tbbnrb);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Name = "returnbook";
            this.Text = "returnbook";
            ((System.ComponentModel.ISupportInitialize)(this.dtgvissue)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label tbbnrb;
        private System.Windows.Forms.Label tbunamerb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbbookid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbbbbb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbbnissue;
        private System.Windows.Forms.Label dcjnkjcnjc;
        private System.Windows.Forms.TextBox tbsidrb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox stdnamerb;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbqunrb;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox tttttttttt;
        private System.Windows.Forms.Button View;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dtgvissue;
        private System.Windows.Forms.Button button3;
    }
}
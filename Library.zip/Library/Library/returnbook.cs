﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BL;
using BEL;

namespace Library
{
    public partial class returnbook : Form
    {
        public Operations opr = new Operations();
        LibraryEmploye le = new LibraryEmploye();
       // Books bq = new Books();
        public returnbook()
        {
            InitializeComponent();
        }
        public returnbook(LibraryEmploye le)
        {
            InitializeComponent();
            this.le = le;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string bookname = textBox1.Text;
            string username = textBox2.Text;

            DataTable dt = new DataTable();
            try
            {
                if (bookname == "") { throw new Exception(); }
                if (username == "") { throw new Exception(); }
                dt = opr.srchforreturn(bookname,username);
                dtgvissue.DataSource = dt;
               

            }
            catch (Exception)
            {
                MessageBox.Show("You must have to full fill name and gmail  ", "Informtion", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        

        private void View_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
          dt=  opr.displayallissue();
            dtgvissue.DataSource = dt;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string isid= tbbbbb.Text;
            string bookid = tbbookid.Text;
            int tbqn = Convert.ToInt32(tbqunrb.Text);
            int issuebooknum = tbqn - 1;
            string upibn = Convert.ToString(issuebooknum);

           // MessageBox.Show(upibn);
            //bbbbbbbbbqqqqqqqqqqqqqqq
            int x= opr.getbookqn(bookid)+1;
            //int nbq = getbookqn + 1;
            string passbookqn = Convert.ToString(x);
            opr.updatebookquan(passbookqn,bookid);
            opr.updatebookissuequan(upibn,isid);
            MessageBox.Show("successfully");


            }

        private void dtgvissue_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            tbbbbb.Text = dtgvissue.Rows[e.RowIndex].Cells[0].Value.ToString();
            tbbnissue.Text = dtgvissue.Rows[e.RowIndex].Cells[5].Value.ToString();
            stdnamerb.Text = dtgvissue.Rows[e.RowIndex].Cells[1].Value.ToString();
            tbqunrb.Text = dtgvissue.Rows[e.RowIndex].Cells[7].Value.ToString();
            tttttttttt.Text = dtgvissue.Rows[e.RowIndex].Cells[6].Value.ToString();
            tbbookid.Text = dtgvissue.Rows[e.RowIndex].Cells[9].Value.ToString();
            tbsidrb.Text = dtgvissue.Rows[e.RowIndex].Cells[8].Value.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            le.Show();

        }
    }
}
